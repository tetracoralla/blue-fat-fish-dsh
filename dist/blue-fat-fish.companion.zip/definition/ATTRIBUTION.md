# 角色来源与分发边界

蓝色大肥鱼／鲸鱼娘是非官方社区同人角色，与 DeepSeek、OpenAI 或 Anthropic 均无官方隶属或背书关系。

## 署名链

- 上善无形（上善）：鲸鱼娘原始角色形象；原作与 CC BY-NC-SA 4.0 声明：https://www.bilibili.com/opus/1231977657712771073
- ZipZipPipe：加入 DeepSeek 元素的女仆鲸鱼娘二次设计；来源：https://www.pixiv.net/artworks/148186519 和 https://www.bilibili.com/video/BV1tE9XBbErS/
- YunYueSama：社区 Q 版设定图参考与相关新增贡献；来源：https://github.com/YunYueSama/codex-deepseek-pet 。其完整署名许可与素材权利范围说明随附于 `licenses/YunYueSama/LICENSE.md` 和 `licenses/YunYueSama/ASSET_LICENSE.md`；素材说明的相对许可链接已按包内文件名调整。
- xiaoweigen：AI 辅助改编、造型变体、设定图整理与公开来源链；来源：https://github.com/xiaoweigen/deepseek-dafeiyu-assets
- OpenAdam：本包的成年人体 Shell 立绘、Q 版动作身体、动作编排、主题与适配数据；使用 AI 辅助重新绘制和确定性图像处理。

## 上游条件

本包的衍生角色美术使用了上述角色设计链。上游公开条件要求署名、仅限非商业使用，并在公开分享演绎作品时采用 CC BY-NC-SA 4.0 或其允许的兼容许可，同时保留修改说明：

- 许可摘要：https://creativecommons.org/licenses/by-nc-sa/4.0/
- 完整条款：https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode
- 上游说明：https://github.com/xiaoweigen/deepseek-dafeiyu-assets

这些条件不授予商用权。任何以商业优势或金钱报酬为主要目的的使用，都需要另行取得相关权利人的许可。

## 本包许可

本 Companion Bundle 及其中的 OpenAdam 新增美术与编排贡献以 CC BY-NC-SA 4.0 分发；完整的包内许可说明见 `LICENSE.md`。再分发或公开改编时必须保留本署名链和修改说明，仅限非商业用途，并以相同许可共享。

DeepSeek、OpenAI、Anthropic 及相关标识仍属于各自权利人。本包中的名称和视觉引用只用于说明非官方同人来源，不构成官方背书，也不额外授予商标权。
