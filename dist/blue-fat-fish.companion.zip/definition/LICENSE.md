# 蓝色大肥鱼 Companion Bundle 许可

SPDX-License-Identifier: CC-BY-NC-SA-4.0

除 `ATTRIBUTION.md` 另行记录的上游权利与品牌标识外，OpenAdam 以 **Creative Commons 署名—非商业性使用—相同方式共享 4.0 国际许可协议（CC BY-NC-SA 4.0）** 提供本 Companion Bundle 的新增美术、动作编排、主题、描述与数据组合。

你可以在遵守许可条件的前提下复制、分享和改编本包：

- 保留 `ATTRIBUTION.md` 中的完整署名链、来源和修改说明；
- 仅用于非商业目的；
- 公开分享改编版本时继续采用 CC BY-NC-SA 4.0；
- 不暗示 DeepSeek、OpenAI、Anthropic、原作者或 OpenAdam 对你的使用提供官方背书。

许可摘要：https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh-hans

完整法律文本：https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode

如许可摘要与完整法律文本存在差异，以完整法律文本为准。商业使用需要另外取得所有相关权利人的明确授权。
